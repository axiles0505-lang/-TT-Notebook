package com.tt.notebook

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NotebookScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotebookScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("tt_notebook", 0) }
    var draft by remember { mutableStateOf("") }
    var notes by remember {
        mutableStateOf(prefs.getStringSet("notes", emptySet())!!.toList().sortedDescending())
    }
    var recording by remember { mutableStateOf(false) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var message by remember { mutableStateOf("Записи сохраняются на этом телефоне.") }

    fun saveNote(value: String) {
        val clean = value.trim()
        if (clean.isNotEmpty()) {
            val updated = (notes + "${System.currentTimeMillis()}|$clean").distinct().sortedDescending()
            notes = updated
            prefs.edit().putStringSet("notes", updated.toSet()).apply()
            draft = ""
            message = "Заметка сохранена"
        }
    }

    val permission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) message = "Нажми «Начать запись» ещё раз."
        else message = "Для записи нужен доступ к микрофону."
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("TT Notebook") }) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Твой личный голосовой блокнот", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = draft, onValueChange = { draft = it },
                modifier = Modifier.fillMaxWidth(), minLines = 3,
                label = { Text("Новая заметка") },
                placeholder = { Text("Запиши задачу, расход, идею или мысль…") }
            )
            Button(onClick = { saveNote(draft) }, modifier = Modifier.fillMaxWidth()) {
                Text("Сохранить заметку")
            }
            Button(
                onClick = {
                    if (!recording) {
                        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                        if (!granted) {
                            permission.launch(Manifest.permission.RECORD_AUDIO)
                        } else {
                            try {
                                val file = File(context.filesDir, "voice_${System.currentTimeMillis()}.m4a")
                                val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()
                                r.setAudioSource(MediaRecorder.AudioSource.MIC)
                                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                                r.setOutputFile(file.absolutePath)
                                r.prepare()
                                r.start()
                                recorder = r
                                recording = true
                                message = "Идёт запись. Нажми «Остановить», чтобы сохранить аудио."
                            } catch (e: Exception) {
                                message = "Не удалось начать запись: ${e.localizedMessage ?: "ошибка"}"
                            }
                        }
                    } else {
                        try {
                            recorder?.stop()
                            recorder?.release()
                            recorder = null
                            recording = false
                            message = "Аудиозапись сохранена в памяти приложения."
                        } catch (e: Exception) {
                            recorder?.release()
                            recorder = null
                            recording = false
                            message = "Запись не сохранена корректно. Попробуй ещё раз."
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = if (recording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            ) { Text(if (recording) "Остановить запись" else "Начать голосовую запись") }
            Text(message, style = MaterialTheme.typography.bodySmall)
            Divider()
            Text("Последние заметки", style = MaterialTheme.typography.titleMedium)
            if (notes.isEmpty()) Text("Пока нет заметок. Добавь первую запись выше.")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(notes, key = { it }) { item ->
                    val content = item.substringAfter("|", item)
                    Card(Modifier.fillMaxWidth()) {
                        Text(content, Modifier.padding(12.dp))
                    }
                }
            }
        }
    }
}
